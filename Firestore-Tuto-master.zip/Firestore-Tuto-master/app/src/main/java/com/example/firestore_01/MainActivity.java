package com.example.firestore_01;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.SetOptions;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    /*** Cette exemple présente une application qui permet de sauvegarder des notes dans firestore
     *  On a un champ Titre et un champ note
     */

    /** Attribut TAG en autocomplétion avec logt **/
    private static final String TAG = "MainActivity";

    /** Variables Globales des clés de notre bases **/
    private static final String KEY_TITRE = "titre";
    private static final String KEY_NOTE = "note";

    /** Attributs globaux **/
    private EditText et_titre, et_note;
    private TextView tv_saveNote, tv_showNote;
    /** Référence de la db de Firebase **/
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    // on fait appelle à notre base de donnée dans laquelle on va ajouter
    // une collection appelée liste de message et un document comprenant nos données
    // si ce document est vide alors Firebase ajoutera un id automatiquement
    private DocumentReference noteRef =  db.collection("listeDeNotes").document("Ma première note");
    /** On peut d'une part écrire cette définition comme suit **/
    //   private DocumentReference noteRef = db.document("listeDeNotes/Ma première note");
    /** D'autre part on peut même déclarer notre collection puis ensuite notre document **/
    //private CollectionReference collectionReference = db.collection("listeDesNotes");
    //private DocumentReference documentReference = db.document("Ma première note");

    /**
     * Méthode initUI()
     **/
    public void initUI() {
        et_titre = (EditText) findViewById(R.id.et_titre);
        et_note = (EditText) findViewById(R.id.et_note);
        tv_saveNote = (TextView) findViewById(R.id.tv_saveNote);
        tv_showNote = (TextView) findViewById(R.id.tv_showNote);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /** Appel des méthodes **/
        initUI();

    }

    /**
     * Création de la méthode onClick du bouton
     **/
    public void saveNote(View view) {
        String titre = et_titre.getText().toString();
        String note = et_note.getText().toString();

        /** Containeur pour transmettre ces données à Firestore **/
        // Map fonctionne sur un modèle clé valeurs
        // Ici on donne le type de donnée puis un object comme ça on peut tout passer
        Map<String, Object> contenuNote = new HashMap<>();
        contenuNote.put(KEY_TITRE, titre);
        contenuNote.put(KEY_NOTE, note);

        /** Envoi des données dans FireStore **/

            noteRef.set(contenuNote)
                // Ajout du addOnSuccessListener pour vérifier que tout c'est bien passé
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(MainActivity.this, "Note enregistrée", Toast.LENGTH_SHORT).show();
                    }
                })
                // Ajout du addOnFailureListener qui affichera l'erreur dans le log d
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity.this, "Erreur lors de l'envoi !", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }

    /** Il existe deux méthodes pour afficher le contenu de la base : un listener qui affiche les changements
     * en temps réel ou l'implémentation d'un bouton pour lafficher seulement lors du clic
     *
     * La première avec le bouton -> Ajout d'un bouton et d'un TextView dans le layout
     */
    public void loadNote(View view){
        noteRef.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    /** documentsSnapshot contient toutes les données auxquelles nous voulons accéder
                     * (tant qu'il en exite bien sûr) **/
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if(documentSnapshot.exists()){
                            /** Pour récupérer nos données on créer une string qui va recevoir les données liées aux clés**/
                            String titre = documentSnapshot.getString(KEY_TITRE);
                            String note = documentSnapshot.getString(KEY_NOTE);
                            // On peut aussi créer une Map avec les résultats
//                            Map<String, Object> note = documentSnapshot.getData();
                            tv_saveNote.setText("Titre de la note : " + titre + "\n" + "Note : " + note);
                        } else {
                            Toast.makeText(MainActivity.this, "Le document n'existe pas !", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity.this, "Erreur de lecture !", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }
    /** La seconde en temps réel --> Ajout d'un second textView dans le layout
     * Pour instancier cette méthode il faut la lancer dès le début de notre activité donc dans le onStart
     * On utilise ici un snapshotListener qui écoute s'il y a des changements dans les snaptshots et auquel cas
     * les affiche automatiquement en temps réel. Pour info les données sont d'abord affichées dans l'app puis
     * transmisent à la base de données.
     */

    @Override
    protected void onStart() {
        super.onStart();
        // Ce Listener tourne en tache de fond il faut donc l'arrêter lorsque l'on change d'activité ou de fragment
        // Il existe deux méthodes : la 1ère consiste à déclarer une variable de type ListenerRegistration, encapsuler
        // le addSnapshotListener avec puis utiliser remove dans la méthode onStop pour l'arréter. La seconde consiste à
        // ajouter this (le context) pour détacher notre listener au moment approprié
       noteRef.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                /** On vérifie qu'il n'y ai pas d"erreur **/
                if(error != null) {
                    Toast.makeText(MainActivity.this, "Erreur au chargement !", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, error.toString());
                    return; // pour quitter la méthode s'il y a une erreur
                }

                if(value.exists()) {
                    String titre = value.getString(KEY_TITRE);
                    String note = value.getString(KEY_NOTE);
                    tv_showNote.setText("Titre de la note : " + titre + "\n" + "Note : " + note);
                } // partie ajoutée pour ne pas afficher null dans le champ
                else {
                    tv_showNote.setText("");
                }
            }
        });
    }

    /** Comment ne changer qu'une seule des valeurs, ici le contenu de la note
     * La méthode suivante permet de changer le contenu de la note sans en changer le titre
     * Paur l'utiliser il faut ajouter un nouveau bouton "MAJ note" auquel on ajoute la méthode suivante **/
    public void updateNote(View view){
        String textNote = et_note.getText().toString();
        /** Méthode 1 **/
        // Création de Map sans mettre la clé du titre
        //Map<String, Object> note = new HashMap<>();
        //note.put(KEY_NOTE, textNote);
        // Si l'on fait un set sans SetOptions.merge la valeur titre sera à null !
        // Si le document n'existe pas il sera créé sans le document titre sinon il n'y aura que le contenu de la note
        // de modifié
        //noteRef.set(note, SetOptions.merge());

        /** Méthode 2 **/
        // Attention si le document n'existe pas il ne sear pas créé dans la base
        noteRef.update(KEY_NOTE, textNote);
    }

    /** Comment effacer un document ou une partie spécifique de notre collection
     * Ajout d'un bouton supprimer note et un bouton tout supprimer**/
    public void deleteNote(View view){
       /** Methode 1
        Map<String, Object> note = new HashMap<>();
        note.put(KEY_NOTE, FieldValue.delete());
        noteRef.update(note);
        **/

       /** Métode 2 **/
       noteRef.update(KEY_NOTE, FieldValue.delete())
               // On peut ajouter un onSuccessListener pour valider notre action
               .addOnSuccessListener(new OnSuccessListener<Void>() {
                   @Override
                   public void onSuccess(Void aVoid) {
                       Toast.makeText(MainActivity.this, "La note est bien supprimée !", Toast.LENGTH_SHORT).show();
                   }
               })
                // Et bien sur un on FailureListener pour afficher l'erreur dans un log
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity.this, "Erreur lors de la suppression !", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
        }

        public void deleteAll(View view){
        /** Méthode 1
        Map<String, Object> note = new HashMap<>();
        note.put(KEY_NOTE, FieldValue.delete());
        note.put(KEY_TITRE, FieldValue.delete());
        noteRef.update(note); */

        /** Méthode 2 **/
        //noteRef.update(KEY_TITRE, KEY_TITRE, FieldValue.delete())
            noteRef.delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(MainActivity.this, "Toute la note est bien supprimée !", Toast.LENGTH_SHORT).show();
                    }
                })
                // Et bien sur un on FailureListener pour afficher l'erreur dans un log
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity.this, "Erreur lors de la suppression !", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
            /** Après la suppression totale il faut ajouter un else dans la méthode onStart pour afficher du texte vide sinon on va
             * afficher null.
             */
        }
}

/** La suite est dans la classe Note dans laquelle on va créer un objet personnalisé qui nous permettra de gérer les données de la base **/