package com.example.firestore_01;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.SetOptions;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class MainActivity_2 extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    private static final String KEY_TITRE = "titre";
    private static final String KEY_NOTE = "note";

    private EditText et_titre, et_note;
    private TextView tv_saveNote, tv_showNote;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    private DocumentReference noteRef = db.document("listeDeNotes/Ma première note");

    public void initUI() {
        et_titre = (EditText) findViewById(R.id.et_titre);
        et_note = (EditText) findViewById(R.id.et_note);
        tv_saveNote = (TextView) findViewById(R.id.tv_saveNote);
        tv_showNote = (TextView) findViewById(R.id.tv_showNote);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_2);

        initUI();
    }

    public void saveNote(View view) {
        String titre = et_titre.getText().toString();
        String note = et_note.getText().toString();

        /** Utilisation du constructeur de la classe Note **/
        Note contenuNote = new Note(titre, note);

        noteRef.set(contenuNote)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(MainActivity_2.this, "Note enregistrée", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity_2.this, "Erreur lors de l'envoi !", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }

    public void loadNote(View view) {
        noteRef.get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        if (documentSnapshot.exists()) {
                            /** On peut supprimer les quatre lignes suivantes */
//                            String titre = documentSnapshot.getString(KEY_TITRE);
//                            String note = documentSnapshot.getString(KEY_NOTE);
//                            // On peut aussi créer une Map avec les résultats
//                            Map<String, Object> note = documentSnapshot.getData();

                            /** Elles sont remplacées par **/
                            Note contenuNote = documentSnapshot.toObject(Note.class);

                            /** Cependant il faut utiliser les getters pour créer deux objets String contenant nos variables
                             */
                            String titre = contenuNote.getTitre();
                            String note = contenuNote.getNote();

                            tv_saveNote.setText("Titre de la note : " + titre + "\n" + "Note : " + note);

                            /** !! Ces lignes sont aussi appelées dans la méthode onStart **/

                        } else {
                            tv_saveNote.setText("");
                            Toast.makeText(MainActivity_2.this, "Le document n'existe pas !", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity_2.this, "Erreur de lecture !", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }

    @Override
    protected void onStart() {
        super.onStart();
        noteRef.addSnapshotListener(this, new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot value, @Nullable FirebaseFirestoreException error) {
                /** On vérifie qu'il n'y ai pas d"erreur **/
                if (error != null) {
                    Toast.makeText(MainActivity_2.this, "Erreur au chargement !", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, error.toString());
                    return; // pour quitter la méthode s'il y a une erreur
                }

                if (value.exists()) {
                    /** Utilisation de notre constructeur **/
                    Note contenuNote = value.toObject(Note.class);

                    String titre = contenuNote.getTitre();
                    String note = contenuNote.getNote();

                    tv_showNote.setText("Objet du message : " + titre + "\n" + "Message : " + note);
                }
                else {
                    tv_showNote.setText("");
                }
            }
        });
    }

    public void updateNote(View view) {
        String textNote = et_note.getText().toString();
        noteRef.update(KEY_NOTE, textNote);
    }


    public void deleteNote(View view) {
        noteRef.update(KEY_NOTE, FieldValue.delete())
                // On peut ajouter un onSuccessListener pour valider notre action
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(MainActivity_2.this, "La note est bien supprimée !", Toast.LENGTH_SHORT).show();
                    }
                })
                // Et bien sur un on FailureListener pour afficher l'erreur dans un log
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity_2.this, "Erreur lors de la suppression !", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }

    public void deleteAll(View view) {
        noteRef.delete()
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Toast.makeText(MainActivity_2.this, "Toute la note est bien supprimée !", Toast.LENGTH_SHORT).show();
                    }
                })
                // Et bien sur un on FailureListener pour afficher l'erreur dans un log
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity_2.this, "Erreur lors de la suppression !", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }
}

/** Comme pour passer de la première partie à la seconde partie, modifier le manifest pour afficher le MainActivity_3 et
 * continnuer l'exmeple et passer à l'enregistrement de plusieurs notes et leurs affichage **/