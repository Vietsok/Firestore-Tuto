package com.example.firestore_01;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class MainActivity_3 extends AppCompatActivity {

    private static final String TAG = "MainActivity_3";

    private EditText et_titre, et_note;
    private TextView tv_showNote;
    private FirebaseFirestore db = FirebaseFirestore.getInstance();

    /**
     * Ajout de la référence à la collection comprenant toutes les notes : notebook
     **/
    private CollectionReference notebookRef = db.collection("Notebook");

    private DocumentReference noteRef = db.document("listeDeNotes/Ma première note");

    public void initUI() {
        et_titre = (EditText) findViewById(R.id.et_titre);
        et_note = (EditText) findViewById(R.id.et_note);
        tv_showNote = (TextView) findViewById(R.id.tv_showNote);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_3);
        initUI();
    }

    /**
     * La méthode pour ajouter des notes dans la base
     **/
    public void addNote(View view) {
        String titre = et_titre.getText().toString();
        String note = et_note.getText().toString();

        Note contenuNote = new Note(titre, note);

        /** On appelle la référence à la collection notebook pour y ajouter les valeurs de l'objet contenuNote **/
        notebookRef.add(contenuNote)
                .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                    @Override
                    public void onSuccess(DocumentReference documentReference) {
                        Toast.makeText(MainActivity_3.this, "Enregistrement de  " + titre, Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(MainActivity_3.this, "Erreur lors de l'ajout ! ", Toast.LENGTH_SHORT).show();
                        Log.d(TAG, e.toString());
                    }
                });
    }

    public void loadNotes(View view) {
        /** Récupération de l'ensemble des documents de notre collections **/
        notebookRef.get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    /** On note l'utilisation de QuerySnapshot pour l'ensemble des valeurs de la base **/
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        String notes = ""; // Déclaration d'un empty string pour remplir le textView plutôt que de déclarer
                        // une liste et de remplir un recycler
                        /** Utilisation d'un boucle for pour faire le tour de la base
                         * les : signifie que l'on utilise un for each  **/
                        for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                            Note contenuNote = documentSnapshot.toObject(Note.class);
                            /** Récupération de l'ID **/
                            contenuNote.setDocumentId(documentSnapshot.getId());

                            String documentId = contenuNote.getDocumentId();
                            String titre = contenuNote.getTitre();
                            String note = contenuNote.getNote();

                            notes += documentId + "\nTitre : " + titre + "\nNote : " + note + "\n\n";
                        }
                        tv_showNote.setText(notes);
                    }
                });
    }

    /** Affichage automatique des notes **/
    @Override
    protected void onStart() {
        super.onStart();
                /** Ne aps oublie d'ajouter this pour détacher le listener quand nous n'en n'avons plus besoin **/
            notebookRef.addSnapshotListener(this, new EventListener<QuerySnapshot>() {
                @Override
                public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                    if(error != null) {
                        return;
                    }
                    String notes = "";
                    for(QueryDocumentSnapshot documentSnapshot : value){
                        Note contenuNote = documentSnapshot.toObject(Note.class);
                        /** Récupération de l'ID **/
                        contenuNote.setDocumentId(documentSnapshot.getId());

                        String documentId = contenuNote.getDocumentId();
                        String titre = contenuNote.getTitre();
                        String note = contenuNote.getNote();

                        notes += documentId + "\nTitre : " + titre + "\nNote : " + note + "\n\n";
                    }
                    tv_showNote.setText(notes);
                }
            });
    }
}

/** Pour retrouver un document dans la collection et le modifier il faut en premier lieu ajouter l'id dans le constructeur **/

/**
 * Comme pour passer de la première partie à la seconde partie, modifier le manifest pour afficher le MainActivity_3 et
 * continnuer l'exmeple et passer à l'enregistrement de plusieurs notes et leurs affichage
 **/