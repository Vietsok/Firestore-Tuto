package com.example.firestore_01;

import com.google.firebase.firestore.Exclude;

/** Cette clase contient le constructeur et les getters et setters qui nous permettent
 * une communication plus simple avec FireStore et seulement si les noms sont identiques !
 *
 * Grâce à cette implémentation nous n'avons plus besoin de
 *      Map<String, Object> contenuNote = new HashMap<>();
 *         contenuNote.put(KEY_TITRE, titre);
 *         contenuNote.put(KEY_NOTE, note);
 *
 * pour faire le lien entre les clés et les valeurs il suffira d'appeler
 *
 *
 *  Pour plus de simplicité l'exemple continuera dans MainActivity_2, pour en faire le LAUNCHER
 *  de noter app déplacer <intent-filter> [...] </intent-filter> dans le fichier AndroidManifest
 *
 *  Petit rappel, ce fichier "s'écrit" en quelques secondes grâce à l'autocomplétion d'Android Studio
 *    - Ajouter à la main les variables dont vous avez besoin
 *    - Cliquer sur [ALT] + [INSER] pour ajouter
 *       - Le constructeur vide
 *       - Le constructeur avec les paramétres
 *       - Les getters et les Setters
 *
 */

public class Note {
    private String documentId;
    private String titre;
    private String note;

    public Note() {

    }

    public Note(String titre, String note) {
        this.titre = titre;
        this.note = note;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    /** On ne veut pas enregistrer l'id dans notre la base car il existe déja nous voulons juste l'utilisé
     *  il faut ajouter @Exclude seulement devant le getter pour ne pas l'enregistrer dans la collection
     *  du document sélectionné
     */
    @Exclude
    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

}
